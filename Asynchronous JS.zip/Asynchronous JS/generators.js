//Executes the iterative code
//Naming Nomenclature - Generators function*
//done-false -> fn is not yet completed
// normal fn - return -> generator fn - yield -> next(), return(), throw()

// function* simpleGenerator(){
//    // console.log('before 1');
// yield 1; 
//    // console.log('after 1');
//    // console.log('before 2');
// yield 2;
//    // console.log('after 2');
//    // console.log('before 3');
// yield 3;
//    // console.log('after 3');
// }

// const obj = simpleGenerator();
// const obj2 = simpleGenerator();
// console.log(obj.next());
// console.log(obj.next());
// console.log(obj2.next());
// console.log(obj2.next());
// console.log(obj.next());
// console.log(obj2.next());
// console.log(obj.next());
// console.log(obj2.next());

// const o1 = simpleGenerator()
// console.log(o1.next());
// console.log(o1.next());
// const o2 = simpleGenerator()
// console.log(o2.next());
// console.log(o2.next());


// function* generator(array){
//     for(let i=0;i<array.length;i++){
//         yield array[i];
//     }
// }
// const gObj1 = generator([10,30,5,7,8]);
// console.log(gObj1.next());
// console.log(gObj1.next());
// console.log(gObj1.next());
// console.log(gObj1.next());

// while(!gObj1.next().done){
//     console.log(gObj1.next());
// }

function* idGenerate(){
    let id=10;
    while(true){
        const inc = yield id;
        if(inc!=null){
            id+=inc;
        }else{
            id++;
        }
    }
}

const obj = idGenerate();
console.log(obj.next());// untouched
console.log(obj.next());
console.log(obj.next(3));
console.log(obj.return(10));
console.log(obj.next());
console.log(obj.throw(new Error("Error while Yielding")));
