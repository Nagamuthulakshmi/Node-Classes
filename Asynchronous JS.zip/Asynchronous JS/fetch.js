//fetch is an async method and returns a promise then, catch
// fetch('jsondata/h1.json')
// .then((response)=>{
//     return response.json()
// }).then((data)=>{console.log(data);})
// .catch((err)=>{console.log(err);})

const getPosts =  async ()=>{
const response= await fetch('jsondata/h1.json');
if(response.status!==200){
    throw new Error("Unable to fetch Data");
}
const data = await response.json();
return data;
} 

getPosts()
.then((data)=>{console.log(data);})
.catch((err)=>{console.log(err.message);})

//fetch('jsondata/h1.json') response.json() - 2 Promise