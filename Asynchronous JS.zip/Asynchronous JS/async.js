console.log(1);
console.log(2);
setTimeout(()=>{
    console.log("Calling back")
},2000);
console.log(3);
console.log(4);