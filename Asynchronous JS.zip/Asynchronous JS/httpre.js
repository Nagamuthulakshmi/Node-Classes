const request = new XMLHttpRequest();
//xmlhttprequest class handle xml, text,json


const getPosts =((resource)=>{
    return new Promise((resolve,reject)=>{
    request.addEventListener('readystatechange',()=>{
        if(request.readyState===4 && request.status===200){
            const data = JSON.parse(request.responseText);
            //Shows me array of objects
       // callback(undefined,data);
        //console.log(request,request.responseText);
        resolve(data)
    }
        else if(request.readyState===4){
       // callback("Not able to fetch data",undefined);
        //console.log("Not able to fetch data");
reject('Error')
    }
    })
    request.open('GET',resource);
    //request.open('GET','https://jsonplaceholder.typicode.com/posts/');
    request.send();
});
});

getPosts('jsondata/h1.json').then(data=>{console.log('Recieved',data);}).catch(err=>{console.log('Error');});

// console.log(1);
// console.log(2);
// getPosts('jsondata/h1.json',(err,data)=>{
//         console.log(data); //datatype? JSON - Javascript Object Notation - series of string "[{sdjhsvjn:dhd}]"
//     getPosts('jsondata/h2.json',(err,data)=>{
//         console.log(data);
//         getPosts('jsondata/h3.json',(err,data)=>{
//             console.log(data);
// });
//     });
// });

// const getSomething = () =>{
//     return new Promise((resolve,reject)=>{//builtin objects of promise class
// //resolve('Some data');
// reject('Some error');
//     }); //async - requires time, callback resolve or reject
// }

// getSomething().then(data=>{console.log(data);},err=>{console.log(err);})

// console.log(3);
// console.log(4);

