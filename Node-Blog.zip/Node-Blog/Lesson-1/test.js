const name = 'yoshi';

console.log(name);